# Append Suffix (XDev)

This is part of the **XDev** learning kit. See the repository README for a guided tour.

## Usage
- Wire the inputs as indicated on the node.
- Hover `?` badges for parameter tooltips.
- Open the node menu → **XDev: Docs** for more resources.
