# Testing & CI

- Unit test pure‑Python logic with `pytest`
- Keep node IO small and deterministic for testability
- Consider Comfy‑Action CI to run a workflow in GitHub Actions
