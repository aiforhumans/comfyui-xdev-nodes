# Packaging & Registry

- Fill `pyproject.toml` with `[project]` and `[tool.comfy]`
- Semantic versioning, publisher id, and metadata
- For Manager: include `requirements.txt`, optional `install.py`/`uninstall.py`, etc.
