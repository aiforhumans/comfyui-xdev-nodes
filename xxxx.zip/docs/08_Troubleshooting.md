# Troubleshooting

- Check the Python console for import errors at startup
- Binary‑search problematic custom nodes by disabling half at a time
- Validate datatypes/shapes early; return tuples for outputs
