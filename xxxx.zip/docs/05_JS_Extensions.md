# JS Extensions (WEB_DIRECTORY)

- Export `WEB_DIRECTORY` in `__init__.py`
- Put frontend code under `xdev_nodes/web/js`
- You can add menus, keybindings, side/bottom tabs, and more
- Provide **Help Page** docs under `xdev_nodes/web/docs` to render rich per‑node docs in the UI
