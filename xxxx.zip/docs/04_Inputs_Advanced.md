# Hidden & Flexible Inputs

- `required` vs `optional` in `INPUT_TYPES`
- `hidden` inputs for values the user doesn't wire (advanced)
- Defining **custom datatypes** to pass structured Python objects between your nodes
